#!/bin/sh
cd `dirname $0`
ROOT_PATH=`pwd`
java -Xmx2048M -cp .:$ROOT_PATH:$ROOT_PATH/../lib/routines.jar:$ROOT_PATH/../lib/mongo-java-driver-3.6.0.jar:$ROOT_PATH/../lib/commons-io-2.5.jar:$ROOT_PATH/../lib/axis.jar:$ROOT_PATH/../lib/dom4j-1.6.1.jar:$ROOT_PATH/../lib/jaxrpc.jar:$ROOT_PATH/../lib/log4j-1.2.16.jar:$ROOT_PATH/create_market_support_table_from_mongodb_2_1.jar: local_project.create_market_support_table_from_mongodb_2_1.Create_Market_Support_Table_From_MongoDB --context=Default "$@" 